# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import warnings
warnings.filterwarnings("ignore")

from process_excel import ReadExcel
import params
from datasets import get_source_dataloader,get_target_dataloader
from core import train_src, test_src, tada, test
from models import Encoder, Classifier, Discriminator, CenterLoss
from utils import init_model, load_model,visualize_input, visualize,draw_confusion_matrix
import torch
import numpy as np
import numpy.random as random
from PIL import Image
import matplotlib.pyplot as plt
import os
import torch.utils.data as Data

if __name__=='__main__':
    #加载好数据,其中80%为训练集、20%为测试集 78为种子时效果最好
    seed = 73 # 固定随机数种子，保证每次加载模型结果一样
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    # torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    src_train_test_dataloader = get_source_dataloader()
    src_train = src_train_test_dataloader[0]
    src_test = src_train_test_dataloader[1]

    src_raw_dataset = Data.TensorDataset(params.features_raw_src,params.labels_raw_src)
    src_raw_dataloader = Data.DataLoader(dataset=src_raw_dataset,
                                         batch_size=params.batch_size,
                                         shuffle=True)
    #初始化模型
    src_encoder = init_model(Encoder())
    tgt_encoder = init_model(Encoder())
    classifier = init_model(Classifier())
    discriminator = init_model(Discriminator())

    print('#===========================#\n')
    print('Class-Sensitive Domain Adaptation\n')
    print('#===========================#\n')

    # Save input data distribution plot
    # When done with expectation, this can be ignored
    #visualize_input(src_raw_dataloader, tgt_raw_dataloader, params.img_input)

    print('#=========================================#\n')
    print('\t\tPre-training\n')
    print('#=========================================#\n')

    # Load source model parameters, see load_model in utils.py
    # If final.pt exists, src_encoder is that. Otherwise, start training
    src_encoder, valid_enc = load_model(src_encoder, 'src-encoder-final.pt')
    classifier, valid_cls = load_model(classifier, 'classifier-final.pt')

    if not valid_enc or not valid_cls:
        src_encoder, classifier = train_src(src_encoder, classifier, src_train)
    else:
        print("Use stored model!")
    print('Pretrain done!')

    old_src_encoder = src_encoder

    # Test source model performance
    test_src(src_encoder, classifier, src_test)

    # ===============================#
    #  Task-Aware Domain Adaptation  #
    # ===============================#
    print('#=========================================#\n')
    print('\t  Class-Sensitive Domain Adaptation\n')
    print('#=========================================#\n')

    # 用预训练好的源映射器初始化目标映射器，如果后者也训练完了直接加载即可
    tgt_encoder, _ = load_model(tgt_encoder, 'src-encoder-final.pt')
    tgt_encoder, valid_tgt_enc = load_model(tgt_encoder, 'tgt-encoder-final.pt')
    params.not_assign_pesudo_labels = valid_tgt_enc
    # 加载训练好的新源映射器和新分类器
    new_src_encoder = init_model(Encoder())
    new_classifier = init_model(Classifier())
    new_src_encoder, _ = load_model(new_src_encoder, 'src-encoder-final.pt')
    new_src_encoder, valid_new_src_enc = load_model(new_src_encoder,'src-encoder-final-new.pt')
    new_classifier, _ = load_model(new_classifier, 'classifier-final.pt')
    new_classifier, valid_new_cls = load_model(new_classifier, 'classifier-final-new.pt')

    #现在已经训练好了源类编码器和分类器
    tgt_train_test_dataloader = get_target_dataloader(tgt_encoder,classifier)
    tgt_train = tgt_train_test_dataloader[0]
    tgt_test = tgt_train_test_dataloader[1]

    tgt_raw_dataset = Data.TensorDataset(params.features_raw_tgt,params.labels_raw_tgt)
    tgt_raw_dataloader = Data.DataLoader(dataset=tgt_raw_dataset,
                                         batch_size=params.batch_size,
                                         shuffle=True)
    if params.nums_per_label == 1:
        visualize_input(src_raw_dataloader, tgt_raw_dataloader, params.img_input)
        visualize(src_encoder, src_encoder,src_test, tgt_test, 'Source Only', params.img_src_only)


    # 三样都没有训练完，用tada方法，拿已有的源分类器、源映射器训练出来
    if (valid_tgt_enc and valid_new_src_enc and valid_new_cls) == False:
        new_src_encoder,tgt_encoder,new_classifier = tada(src_encoder, tgt_encoder, discriminator,
                                                          src_train, tgt_train,classifier)
    print('Adaptation done!')

    # Save data distribution by trained TADA
    # When done with expectation, this can be ignored
    if params.nums_per_label == 1:
        visualize(new_src_encoder,tgt_encoder, src_test, tgt_test, 'CADA', params.img_tada)

    # 合并三张图片
    '''
     fig = plt.figure(figsize=(30, 10))
    file_names = [params.img_input, params.img_src_only, params.img_tada]

    for i, file_name in enumerate(file_names):
        img = Image.open(os.path.join(params.img_root, '{}.png'.format(file_name)))

        ax = fig.add_subplot(1, 3, i + 1)
        ax.imshow(img)
        ax.set_xticks([]), ax.set_yticks([])

        os.remove(os.path.join(params.img_root, '{}.png'.format(file_name)))

    plt.subplots_adjust(hspace=0, wspace=0)
    plt.tight_layout()
    plt.savefig(os.path.join(params.img_root, '{}.png'.format(params.img_final)))
    '''
    #===============================#
    #            Testing            #
    #===============================#
    print('\n#=========================================#\n')
    print('\t\tTesting\n')
    print('#=========================================#\n')

    print('>> Source only\n')
    test(old_src_encoder, classifier, tgt_test)

    print('\n>> CSDA\n')
    test(tgt_encoder, new_classifier, tgt_test)

    print('\nTest done')
    # cm->confusion matrix
    #draw_confusion_matrix(old_src_encoder,classifier,tgt_test,'Source Only Confusion Matrix',params.img_cm_src_only)
    #draw_confusion_matrix(tgt_encoder,new_classifier,tgt_test,'TADA_Confusion_matrix',params.img_cm_tada)
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
