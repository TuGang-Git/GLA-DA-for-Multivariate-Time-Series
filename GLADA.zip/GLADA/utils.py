import torch
import torch.nn as nn

import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import seaborn as sns
from sklearn.metrics import confusion_matrix
import os
import params

def get_device():
    """ Get device type """
#gpu_num是gpu编号而不是数量
    device = 'cuda:{}'.format(params.gpu_num) if torch.cuda.is_available() else 'cpu'
    return device

def load_gpu(tensor):
    """ Load tensor to GPU """
    device = get_device()
    #linear只认float的

    tensor = tensor.to(device)
    return tensor

def save_model(model, file_name):
    """ Save model parameters """

    # Make root directory for saving model parameters
    if not os.path.exists(params.model_root):
        os.mkdir(params.model_root)

    # Save model parameters
    torch.save(model.state_dict(), os.path.join(params.model_root, file_name))
    print('  - Save model to {}\n'.format(os.path.join(params.model_root, file_name)))

def set_requires_grad(model, requires_grad=True):
    """ Set requires_grad flag """
    #一些参数更新时要用到导数
    for param in model.parameters():
        param.requires_grad = requires_grad

def load_model(model, file_name):
    """ Load model parameters """

    if not os.path.exists(os.path.join(params.model_root, file_name)):
        return model, False

    model.load_state_dict(torch.load(os.path.join(params.model_root, file_name), map_location=get_device()))
    return model, True

def init_model(model):
    """ Initialize model """

    # Initialize model weight
    for module in model.modules():
        if type(module) == nn.Linear:
            nn.init.xavier_normal_(module.weight)
            nn.init.zeros_(module.bias)
    # Load model to GPU
    model = load_gpu(model)

    return model


def save_plot(X, y, d, mode, file_name):
    """ Save data distribution plot """

    # Set plot size
    plt.figure(figsize=(7, 7))

   # plt.ion()
    c = ['red','blue']
    for i in range(len(d)):
        # Get domain color
        color = [['red', 'mistyrose', 'salmon', 'tomato', 'darksalmon', 'coral',
                  'orangered', 'lightsalmon', 'firebrick', 'indianred'],
                 ['blue', 'mediumblue', 'darkblue', 'midnightblue', 'slateblue',
                  'darkslateblue', 'mediumslateblue', 'lightsteelblue', 'cornflowerblue', 'royalblue']]
        for i in range(len(d)):
            plt.text(x=X[i, 0], y=X[i, 1],
                     s=str(y[i]),
                     color=color[int(d[i])][y[i]],
                     fontdict={'weight': 'light', 'size': 18})

        # Set plot options
    plt.plot(-1000, 0, '.', c='red')
    plt.plot(-1000, 0, '.', c='blue')
    plt.legend(['src', 'tgt'], loc='upper right', fontsize='x-large')
    x_start = X[:, 0].min() * 1.2
    x_end = X[:, 0].max() * 1.2
    y_start = X[:, 1].min() * 1.2
    y_end = X[:, 1].max() * 1.2
    plt.xlim(x_start, x_end)
    plt.ylim(y_start, y_end)
    text=['0:OA Damper Stuck(Fully Close)','1:EA Damper Stuck \n (Fully open)',
          '2:EA Damper Stuck \n (Fully Close)','3:Normal']
    # 在图中注释故障代码，不同的图可能参数不一样，改一下乘的系数后看看实际位置再做调整至合适即可
    # 调整到合适位置后，请在另外一个文件夹里保存或去main里将对应作图函数注释掉或去除，避免受到影响
    '''plt.text(
        x=x_start,y= y_end * 0.95,
        s=text[0],
        fontdict={'weight': 'light', 'size': 10}
    )
    plt.text(
        x=x_start , y=y_end * 0.85,
        s=text[1],
        fontdict={'weight': 'light', 'size': 10}
    )
    plt.text(
        x=x_start, y=y_end * 0.75,
        s=text[2],
        fontdict={'weight': 'light', 'size': 10}
    )
    plt.text(
        x=x_start, y=y_end * 0.65,
        s=text[3],
        fontdict={'weight': 'light', 'size': 10}
    )'''
    plt.xticks([]), plt.yticks([])
    plt.title(mode, fontsize=30)
    plt.tight_layout()
    #plt.draw()
    # Make root directory for saving plots
    if not os.path.exists(params.img_root):
        os.mkdir(params.img_root)

    # Save plot
    plt.savefig(os.path.join(params.img_root, '{}.png'.format(file_name)))
    print('\n#=========================================#\n')
    print('\tSave {} Distribution\n'.format(mode))
    print('  - {}.png\n'.format(os.path.join(params.img_root, file_name)))
    print('#=========================================#\n')


def visualize_input(src_loader, tgt_loader, file_name):
    """ Visualize input data distribution that reduced dimension by T-SNE """

    # Extract sample data from source dataset
    list_src_images = torch.Tensor()
    list_src_labels = torch.Tensor()

    for idx, (images, labels) in enumerate(src_loader):
        if idx == 5:
            break

        list_src_images = torch.cat([list_src_images, images], 0)
        list_src_labels = torch.cat([list_src_labels, labels], 0)

    list_src_domain = torch.ones(list_src_images.shape[0])
    list_src_images = list_src_images.view(list_src_images.shape[0], -1)

    # Extract sample data from target dataset
    list_tgt_images = torch.Tensor()
    list_tgt_labels = torch.Tensor()

    for idx, (images, labels) in enumerate(tgt_loader):
        if idx == 5:
            break

        list_tgt_images = torch.cat([list_tgt_images, images], 0)
        list_tgt_labels = torch.cat([list_tgt_labels, labels], 0)

    list_tgt_domain = torch.zeros(list_tgt_images.shape[0])
    list_tgt_images = list_tgt_images.view(list_tgt_images.shape[0], -1)

    # 连接两域数据
    list_images_concat = torch.cat([list_src_images, list_tgt_images], 0).numpy()
    list_labels_concat = torch.cat([list_src_labels, list_tgt_labels], 0).int().numpy()
    list_domain_concat = torch.cat([list_src_domain, list_tgt_domain], 0).numpy()

    # T-SNE降维
    tsne = TSNE(perplexity=30, n_components=2, init='pca', n_iter=3000)
    adda_tsne = tsne.fit_transform(list_images_concat)

    # 降维后的分布作图
    save_plot(adda_tsne, list_labels_concat, list_domain_concat, 'Raw Data', file_name)


def visualize(src_encoder,tgt_encoder, src_loader, tgt_loader, mode, file_name):
    """ Visualize source and target data distribution that reduced demansion by T-SNE """

    # Extract sample data from source dataset
    list_src_images = torch.Tensor()
    list_src_labels = torch.Tensor()
    list_src_domain = torch.Tensor()

    for idx, (images, labels) in enumerate(src_loader):
        if idx == 5:
            break

        list_src_images = torch.cat([list_src_images, images], 0)
        list_src_labels = torch.cat([list_src_labels, labels], 0)

    list_src_domain = torch.ones(list_src_images.shape[0])

    # Extract sample data from target dataset
    list_tgt_images = torch.Tensor()
    list_tgt_labels = torch.Tensor()
    list_tgt_domain = torch.Tensor()

    for idx, (images, labels) in enumerate(tgt_loader):
        if idx == 5:
            break

        list_tgt_images = torch.cat([list_tgt_images, images], 0)
        list_tgt_labels = torch.cat([list_tgt_labels, labels], 0)

    list_tgt_domain = torch.zeros(list_tgt_images.shape[0])

    list_src_images = load_gpu(list_src_images).float()
    list_tgt_images = load_gpu(list_tgt_images).float()
    # Concatenate source and target data
    list_features_src = src_encoder(list_src_images)
    list_features_tgt = tgt_encoder(list_tgt_images)
    list_features = torch.cat([list_features_src,list_features_tgt],0)
    #list_images_concat = torch.cat([list_src_images, list_tgt_images], 0)
    list_labels_concat = torch.cat([list_src_labels, list_tgt_labels], 0).int().numpy()
    list_domain_concat = torch.cat([list_src_domain, list_tgt_domain], 0).numpy()

    # Extract features
    #list_images_concat = load_gpu(list_images_concat)
    list_features = list_features.detach().cpu().numpy()

    # Reduce dimension by T-SNE
    tsne = TSNE(perplexity=30, n_components=2, init='pca', n_iter=3000)
    adda_tsne = tsne.fit_transform(list_features)

    # Save T-SNE result
    save_plot(adda_tsne, list_labels_concat, list_domain_concat, mode, file_name)

def draw_confusion_matrix(encoder,classifier,loader,mode,file_name):
    sns.set()
    f, ax = plt.subplots()
    y_true = []
    y_pred = []
    encoder.eval()
    classifier.eval()
    with torch.no_grad():
        for data,labels in loader:
            data = load_gpu(data)
            # 把原始标签放入y_true列表中
            y_true = np.hstack((y_true,labels.numpy()))
            preds = classifier(encoder(data))
            # 把预测标签放入y_pred列表中
            y_pred = np.hstack((y_pred,preds.max(1)[1].cpu().numpy()))

    C2 = confusion_matrix(y_true, y_pred, labels=[0, 1, 2, 3, 4, 5, 6])
    #print(C2)
    sns.heatmap(C2, annot=True, ax=ax,fmt='.0f')  # Draw a heat map
    ax.set_title('confusion matrix')  # Title
    ax.set_xlabel('predict')  # x axis
    ax.set_ylabel('true')  # y axis
    plt.title(mode)
    # 要先save再show，不然保存的是一张空图片，因为show完后创建了个新的空白图片
    plt.savefig(os.path.join(params.img_root, '{}.jpg'.format(file_name)))
    #plt.show()

