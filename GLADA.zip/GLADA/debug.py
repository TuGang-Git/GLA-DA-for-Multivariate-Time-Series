# This is used to find faults in codes or files

import torch
from sklearn.manifold import TSNE

import params
from datasets import get_source_dataloader
from core import train_src, test_src, tada, test
from models import Encoder, Classifier, Discriminator
from utils import init_model, load_model, visualize_input, visualize, save_plot,load_gpu
import numpy as np
import numpy.random as random

import os
from PIL import Image
import seaborn as sns
import matplotlib.pyplot as plt
from numpy import *

def relu(x):
    y = x.copy()
    y[y<0] = 0
    return y

def sigmoid(x):
    return 1.0 / (1.0 + exp(-x))

if __name__=='__main__':
    x=np.arange(-2,2,0.01)
    fig = plt.figure()
    #移动y轴值中间，擦除顶端和右端边界线
    ax = fig.add_subplot()
    ax.spines['top'].set_color('none')
    ax.spines['right'].set_color('none')
    ax.spines['left'].set_position(('data', 0))
    ax.spines['bottom'].set_position(('data', 0))
    y_relu=relu(x)
    y_sigmoid=sigmoid(x)
    plt.tick_params(labelsize=14)  # 刻度字体大小14
    plt.plot(x,y_relu,'yellow')
    plt.plot(x,y_sigmoid,'green')
    font={
        'family':'Times New Roman',
        'weight':'light'
    }

    plt.legend(['relu:$\mathdefault{f(x) \equal max(0,x)}$','sigmoid:$\mathdefault{f(x)=\\frac{1}{1+e^{-x}}}$']
               ,loc='upper left',prop=font)

    plt.tight_layout()#自动调整子图参数,使之填充整个图像区域
    plt.show()