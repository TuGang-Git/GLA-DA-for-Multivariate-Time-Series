import warnings

import torchmetrics
from sklearn.semi_supervised import LabelSpreading
import copy
warnings.filterwarnings("ignore")
from sklearn import metrics
from process_excel import ReadExcel
import params
from datasets import  data_generator, Load_Dataset
from datasets.hparams import HAR_params,HHAR_params,EEG_params,WISDM_params
from datasets.data_model_configs import HAR_configs,HHAR_configs,EEG_configs,WISDM_configs
from core import train_src, test_src, tada, test
from utils import get_device,load_gpu
from models import Encoder, Classifier, Discriminator, CenterLoss, classifier, CNN
from utils import init_model, load_model, visualize_input, visualize, draw_confusion_matrix
import torch
import numpy as np
import numpy.random as random
from PIL import Image
import matplotlib.pyplot as plt
import os
import torch.utils.data as Data
from scipy.spatial.distance import euclidean
from fastdtw import fastdtw
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import logging
from datetime import datetime
import time

# 定义DTW距离计算函数
def dtw_distance(x, y):
    distance, _ = fastdtw(x, y, dist=euclidean)
    return distance


if __name__ == '__main__':
    # 绑定随机数种子
    seed = 73
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    # torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    logging.basicConfig(filename="semi_CSDA_"+datetime.now().strftime("%H_%M_%S")+".log", level=logging.INFO,
                        format='%(message)s')

    dataset=("HAR","HHAR","EEG","WISDM")
    #dataset = ("HHAR",)
    for datasetName in dataset:
        if datasetName == "HAR":
            # 获取相关参数
            hparams = HAR_params().train_params
            configs = HAR_configs()
            data_path = "D:\\Datasets\\HAR"
            scenarios = [("7","13"),("9","18"),("22","4"),("4","9"),("12","10")]
        if datasetName =="HHAR":
            hparams = HHAR_params().train_params
            configs = HHAR_configs()
            data_path = "D:\\Datasets\\HHAR"
            scenarios = [("1","6"),("4","5"),("7","4"),("0","3"),("1","5")]
        if datasetName =="EEG":
            hparams = EEG_params().train_params
            configs = EEG_configs()
            data_path = "D:\\Datasets\\EEG"
            scenarios=[("16","1"),("0","11"),("13","1"),("12","4"),("19","9")]
        if datasetName == "WISDM":
            hparams = WISDM_params().train_params
            configs = WISDM_configs()
            data_path = "D:\\Datasets\\WISDM"
            scenarios=[("7","17"),("20","30"),("6","19"),("18","23"),("32","30")]

        for scenario in scenarios:
            start_time = time.time()
            # 获取数据
            source_train_loader, source_test_loader = data_generator(data_path, scenario[0], configs, hparams)
            target_train_loader, target_test_loader = data_generator(data_path, scenario[1], configs, hparams)
            # 初始化模型
            source_model = init_model(CNN(configs))
            cls = init_model(classifier(configs))
            discriminator = init_model(Discriminator())
            # 预训练源域模型
            print("================================")
            print("第一步：预训练源域模型")
            source_model, cls = train_src(source_model, cls, source_train_loader,configs,hparams)
            old_src_encoder = copy.deepcopy(source_model)
            old_cls = copy.deepcopy(cls)

            # 测试源域模型
            test_src(source_model, cls, source_test_loader,configs,hparams)

            # 测试目标域的半监督模型
            # 用CNN对有标签数据微调后再对剩余数据产生特征，拿来做半监督分类
            target_model = source_model
            tgt_cls = cls
            tgt_features = []
            tgt_labels = []
            tgt_test_labels = []
            tgt_test_features = []
            for data, labels in target_train_loader:
                batch_size = len(data)
                for i in range(batch_size):
                    tgt_features.append(data[i].tolist())
                    tgt_labels.append(labels[i].item())
            for data, labels in target_test_loader:
                batch_size = len(data)
                for i in range(batch_size):
                    tgt_test_features.append(data[i].tolist())
                    tgt_test_labels.append(labels[i].item())
            tgt_features = np.array(tgt_features)
            tgt_labels = np.array(tgt_labels)
            tgt_test_features = np.array(tgt_test_features)
            tgt_test_labels = np.array(tgt_test_labels)
            # 统计目标域里每个类有几个数据
            cls_num = [0 for i in range(configs.num_classes)]
            for label in tgt_labels:
                cls_num[label] += 1
            print("cls_num:", cls_num)
            # 处理数据不平衡问题：按照比例来设置每个类留多少有标签数据
            ratio = 0.01
            cls_num_pre = [round(ratio * num) for num in cls_num]
            for i in range(len(cls_num_pre)):
                if cls_num_pre[i] < 1:
                    cls_num_pre[i] = 1
            print("cls_num_pre:", cls_num_pre)
            # 有标签数据集
            tgt_features_labeled = []
            tgt_labels_labeled = []
            # 无标签数据集, 标签集合放的是原本的标签
            tgt_features_unlabeled = []
            tgt_labels_unlabeled = []
            # 记录带标签数据的下标
            labeled_sample_index = []
            # 打乱下标
            indices = np.arange(len(tgt_labels))
            np.random.shuffle(indices)
            tgt_features = tgt_features[indices]
            tgt_labels = tgt_labels[indices]
            # 把原来的标签保留一部分
            for i in range(len(tgt_labels)):
                if cls_num_pre[tgt_labels[i]] != 0:
                    tgt_features_labeled.append(tgt_features[i])
                    tgt_labels_labeled.append(tgt_labels[i])
                    cls_num_pre[tgt_labels[i]] -= 1
                    labeled_sample_index.append(i)
                else:
                    tgt_features_unlabeled.append(tgt_features[i])
                    tgt_labels_unlabeled.append(tgt_labels[i])
            # print(labeled_sample_index)
            # print(np.array(labeled_sample_index).shape)
            # 封装为dataloader
            tgt_features_labeled = torch.tensor(tgt_features_labeled).to(torch.float32)
            tgt_features_unlabeled = torch.tensor(tgt_features_unlabeled).to(torch.float32)
            tgt_labels_labeled = torch.tensor(tgt_labels_labeled).long()
            tgt_labels_unlabeled = torch.tensor(tgt_labels_unlabeled).long()
            print("原始数据的标签维度和特征维度（还没经cnn提取特征!）")
            print(tgt_labels_unlabeled.shape)
            print(tgt_features_unlabeled.shape)
            dataset_labeled = Data.TensorDataset(tgt_features_labeled, tgt_labels_labeled)
            dataset_unlabeled = Data.TensorDataset(tgt_features_unlabeled, tgt_labels_unlabeled)
            dataloader_labeled = Data.DataLoader(dataset=dataset_labeled,
                                                 batch_size=hparams["batch_size"],
                                                 shuffle=False)
            dataloader_unlabeled = Data.DataLoader(dataset=dataset_unlabeled,
                                                   batch_size=hparams["batch_size"],
                                                   shuffle=False)
            #在目标域挑了一些样本，让这些样本是带标签的
            # 记录总的数据量
            total = len(tgt_labels)
            agree = 0
            ori_unlabeled = len(tgt_labels_unlabeled)
            # 赋予伪标签，得到新的dataloader_labeled为目标域数据集，再进行后续迁移
            cpu = torch.device('cpu')

            print("================================")
            print("第二步：给目标域无标签样本赋伪标签")
            # 计算伪标签的准确率
            # 当knn结果与dnn结果相同时，赋伪标签，我们也要计算伪标签的准确率和mf1
            pseudo_labels_list, labels_list = [], []#记录伪标签和真实标签列表
            for epoch in range(3):
                print("Epoch ", epoch + 1, ":")
                # 对有标签目标域数据做微调
                print("对有标签目标域数据做微调")
                target_model, cls = train_src(target_model, cls, dataloader_labeled,configs,hparams)
                # 提取CNN处理特征
                cnn_features = []
                for data, _ in dataloader_labeled:
                    data = load_gpu(data).to(torch.float32)
                    features = target_model(data).detach()
                    # 采用1d-CNN处理后的特征

                    for f in features:
                        cnn_features.append(f.to(cpu).numpy())
                    # 直接用原始数据-效果也很差
                    # for i in range(hparams["batch_size"]):
                    #     cnn_features.append(data[i].numpy().reshape(configs.input_channels*configs.sequence_len))

                # 得到的特征形状：(data_size, configs.sequence_len)
                cnn_features = np.array(cnn_features)
                # 用来做半监督学习
                x_true = cnn_features
                # 需要用深拷贝
                y_true = tgt_labels_labeled.numpy().copy()
                # for i in range(total):
                #     if i not in labeled_sample_index:
                #         y_true[i] = -1
                # 目前最高参数：kernel='rbf', alpha=0.00001, gamma=1
                knn_model = LabelSpreading(kernel='rbf', alpha=0.00001, gamma=1)
                knn_model.fit(x_true, y_true)
                x_train = []
                for data, _ in dataloader_unlabeled:
                    data = load_gpu(data).to(torch.float32)
                    features = target_model(data).detach()
                    # 采用1d-CNN处理后的特征-效果很差
                    for f in features:
                        x_train.append(f.to(cpu).numpy())
                x_train = np.array(x_train)
                y_train = tgt_labels_unlabeled.numpy().copy()
                y_pred_knn = knn_model.predict(x_train)
                # 计算准确率
                y_pred_knn = np.array(y_pred_knn, dtype=np.int32).reshape(-1)
                unlabeled = len(tgt_labels_unlabeled)
                correct = 0
                for i in range(unlabeled):
                    if y_pred_knn[i] == tgt_labels_unlabeled[i]:
                        correct += 1
                print("================================")
                print("Epoch ", epoch + 1, ":")
                print("KNN acc:{:.4f}".format(correct / unlabeled))

                #上面是knn准确率，下面是dnn准确率
                # 神经网络预测结果
                y_pred_dnn = list()
                # 开启测试模式
                target_model.eval()
                cls.eval()
                with torch.no_grad():
                    for data, _ in dataloader_unlabeled:
                        data = load_gpu(data).to(torch.float32)
                        preds = cls(target_model(data))
                        for pred in preds.max(1)[1]:
                            y_pred_dnn.append(pred.item())
                correct = 0
                y_pred_dnn = np.array(y_pred_dnn, dtype=np.int32).reshape(-1)
                # 查看一致结果的个数

                for i in range(unlabeled):
                    if y_pred_dnn[i] == tgt_labels_unlabeled[i]:
                        correct += 1
                # 转化为np数组，执行删除操作
                # print("转化前：", tgt_features_unlabeled.shape)
                tgt_features_unlabeled = tgt_features_unlabeled.numpy()
                tgt_labels_unlabeled = tgt_labels_unlabeled.numpy()
                delete_idx = []


                for i in range(unlabeled):

                    if y_pred_knn[i] == y_pred_dnn[i]:
                        agree += 1
                        labeled_sample_index.append(i)
                        # 把同意标签的数据从unlabeled移到labeled里
                        # 先记住要删除的索引位置
                        delete_idx.append(i)
                        tgt_features_labeled = torch.cat((tgt_features_labeled, torch.tensor(tgt_features_unlabeled[i]).unsqueeze(0)), 0)
                        tgt_labels_labeled = torch.cat((tgt_labels_labeled, torch.tensor(y_pred_knn[i]).unsqueeze(0)), 0)
                        # print("同意的标签", y_pred_dnn[idx])
                        pseudo_labels_list.append(y_pred_dnn[i])
                        labels_list.append(tgt_labels_unlabeled[i])

                        # if y_pred_dnn[i] == tgt_labels_unlabeled[i]:
                        #     if y_pred_dnn[i] not in class_correct.keys():
                        #         class_correct[y_pred_dnn[i]] = 0
                        #         class_pred_count[y_pred_dnn[i]] = 0
                        #         class_real_count[y_pred_dnn[i]] = 0
                        #     class_correct[y_pred_dnn[i]]+=1
                        #     class_pred_count[y_pred_dnn[i]]+=1
                        #     class_real_count[y_pred_dnn[i]]+=1
                        # else:
                        #     if tgt_labels_unlabeled[i] not in class_real_count:
                        #         class_real_count[tgt_labels_unlabeled[i]] = 0
                        #         if tgt_labels_unlabeled[i] not in class_pred_count:
                        #             class_pred_count[tgt_labels_unlabeled[i]] = 0
                        #         if tgt_labels_unlabeled[i] not in class_correct:
                        #             class_correct[tgt_labels_unlabeled[i]] = 0
                        #     if y_pred_dnn[i] not in class_pred_count:
                        #         class_pred_count[y_pred_dnn[i]] = 0
                        #         if y_pred_dnn[i] not in class_real_count:
                        #             class_real_count[y_pred_dnn[i]]=0
                        #         if y_pred_dnn[i] not in class_correct:
                        #             class_correct[y_pred_dnn[i]] =0
                        #     class_real_count[tgt_labels_unlabeled[i]]+=1
                        #     class_pred_count[y_pred_dnn[i]]+=


                full_pseudo_labels=torch.cat((torch.tensor(pseudo_labels_list),))
                full_labels = torch.cat((torch.tensor(labels_list),))
                # 计算准确率和mf1
                cal_acc = torchmetrics.Accuracy(task="multiclass", num_classes=configs.num_classes)
                cal_f1 = torchmetrics.F1Score(task="multiclass", num_classes=configs.num_classes, average="macro")
                acc=cal_acc(full_pseudo_labels.cpu(),full_labels.cpu()).item()
                mf1=cal_f1(full_pseudo_labels.cpu(),full_labels.cpu()).item()


                # print("删除前：", tgt_features_unlabeled.shape)
                # 把同意的数据从unlabeled中移除
                tgt_features_unlabeled = np.delete(tgt_features_unlabeled, delete_idx, axis=0)
                tgt_labels_unlabeled = np.delete(tgt_labels_unlabeled, delete_idx)
                # print("删除后：", tgt_features_unlabeled.shape)
                # 重新封装dataloader
                tgt_features_unlabeled = torch.tensor(tgt_features_unlabeled).to(torch.float32)
                tgt_labels_unlabeled = torch.tensor(tgt_labels_unlabeled).long()
                dataset_labeled = Data.TensorDataset(tgt_features_labeled, tgt_labels_labeled)
                # print(tgt_labels_unlabeled.shape, tgt_features_unlabeled.shape)
                dataset_unlabeled = Data.TensorDataset(tgt_features_unlabeled, tgt_labels_unlabeled)
                dataloader_labeled = Data.DataLoader(dataset=dataset_labeled,
                                                     batch_size=hparams["batch_size"],
                                                     shuffle=False)
                dataloader_unlabeled = Data.DataLoader(dataset=dataset_unlabeled,
                                                       batch_size=hparams["batch_size"],
                                                       shuffle=False)

                print("DNN acc:{:.4f}".format(correct / unlabeled))
                print("同意比例：{:.4f}".format(agree / ori_unlabeled))
                print("同意个数：", agree)
                print(f"伪标签准确率:{acc}")
                print(f"伪标签mf1:{mf1}")

                logging.info(f"{datasetName} {scenario} Epoch:{epoch+1}")
                logging.info(f"{datasetName} {scenario} DNN acc:{correct / unlabeled}")
                logging.info(f"{datasetName} {scenario} 同意比例：{agree / ori_unlabeled}")
                logging.info(f"{datasetName} {scenario} 同意个数:{agree}")
                logging.info(f"{datasetName} {scenario} 伪标签准确率:{acc}")
                logging.info(f"{datasetName} {scenario} 伪标签mf1:{mf1}")
                logging.info(f"\n")

                print("================================")
                # # 设置好变监督学习的变量
                if agree == ori_unlabeled:
                    break



            # 开始迁移
            print('#======================================================================#\n')
            print('\t  Class-Sensitive Domain Adaptation for Multivariate Time Series Data\n')
            print('#======================================================================#\n')


            discriminator = init_model(Discriminator())
            source_model_new, target_model_new, cls_new = tada(source_model, target_model, discriminator,
                                                               source_train_loader, target_train_loader, cls,configs)
            end_time = time.time()
            # print('>> Source only\n')
            # logging.info(f"{datasetName} {scenario} >> Source only")
            # test(old_src_encoder, old_cls, target_test_loader,configs)
            #visualize(old_src_encoder,old_src_encoder,source_test_loader,target_test_loader,mode="Source Only",file_name=f"Source Only {datasetName}_{scenario[0]}_{scenario[1]}")
            print('\n>> CSDA\n')
            logging.info(f"{datasetName} {scenario} '>> CSDA")
            logging.info(f"{end_time-start_time}")
            test(target_model_new, cls_new, target_test_loader,configs)
            #visualize(source_model_new,target_model_new,source_test_loader,target_test_loader,mode="CSDA",file_name=f"CSDA_semi {datasetName}_{scenario[0]}_{scenario[1]}")

            # print('\n Supervised on target\n')
            # logging.info(f"{datasetName} {scenario}  Supervised on target")
            # # 初始化模型
            # target_model = init_model(CNN(configs))
            # target_cls = init_model(classifier(configs))
            # target_model, target_cls = train_src(target_model, target_cls, target_train_loader,configs, hparams)
            # test(target_model,target_cls,target_test_loader,configs)
            logging.info("\n\n\n")

            # x_train = tgt_features
            # y_true = tgt_labels
            # x_test = tgt_test_features
            # y_test = tgt_test_labels
            # init_centers = np.zeros(shape=(configs.input_channels, configs.sequence_len))
            # y_train = np.array([-1 for i in range(len(y_true))])
            # # for i in range(len(y_true)):
            # #     if cls_num_pre[y_true[i]] != 0:
            # #         init_centers[y_true[i]] = init_centers[y_true[i]] + tgt_features[i]
            # #         cls_num_pre[y_true[i]] -= 1
            # #         y_train[i] = y_true[i]
            # # 计算训练集中每个样本之间的DTW距离
            # train_distances = np.zeros((len(x_train), len(x_train)))
            # for i in range(len(x_train)):
            #     for j in range(i, len(x_train)):
            #         distance, _ = fastdtw(x_train[i], x_train[j], dist=euclidean)
            #         train_distances[i, j] = distance
            #         train_distances[j, i] = train_distances[i, j]  # 对称性质
            # knn = KNeighborsClassifier(n_neighbors=3)  # 使用'precomputed'指定自定义距离函数
            # knn.fit(train_distances, y_train)
            #
            # # 计算测试集中每个样本到训练集的DTW距离
            # # 在测试集上计算准确率
            # test_distances = []
            # for i in range(len(x_test)):
            #     distances = []
            #     for j in range(len(x_test)):
            #         distance, _ = fastdtw(x_test[i], x_test[j], dist=euclidean)
            #         distances.append(distance)
            #     test_distances.append(distances)
            # predicted = knn.predict(test_distances)
            # print("Accuracy:{:.2f}".format(metrics.accuracy_score(y_test,predicted)))
