# 此处读取数据,返回读取结果
from process_excel import ReadExcel
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.semi_supervised import LabelSpreading

import params
import torch.utils.data as Data
import torch
from numbers import Number
import numpy as np
import time
from utils import load_gpu
import torch.nn as nn
import torch.optim as optim


# 361 1225 1140
def takeSecond(elem):
    return elem[1]


def get_five_features(features, labels, nrows):
    # 降维处理，选择出几个关键维度
    extractor = ExtraTreesClassifier()
    # features后面的P_E, HWC_VLV这些专家知识矩阵不参与特征选择
    former_features, expert_features = np.split(features, [54], axis=1)
    extractor.fit(former_features, labels)
    index_score = list(enumerate(extractor.feature_importances_))
    index_score.sort(key=takeSecond, reverse=True)
    indices = []
    for elem in index_score[:5]:
        indices.append(elem[0])
    # 维度确保和输入的features维度一致
    # print(indices)
    new_features = np.zeros(shape=(nrows, 5))
    for i in range(len(new_features)):
        count = 0  # Set cnt th feature of the new
        for j in indices:
            new_features[i][count] = former_features[i][j]
            count += 1
    return np.hstack((new_features, expert_features))


def find_nan(data):
    # Find an element that is not a number
    for i in range(len(data)):
        for j in range(len(data[i])):
            if len(data[i]) != len(data[0]):
                print("{}行长度与第一行不一样！".format(i + 1))
            if isinstance(data[i][j], Number) == False:
                print("第{}行{}个元素不是数字".format(i + 1, j + 1))
                return True
    return False


def get_features_and_labels(data):
    features = list()
    labels = list()
    for row in data:
        # 把日期数据剔除出去
        features.append(row[2:59])
        labels.append(data[-1][-1])
    return features, labels


def get_source_dataloader():
    # Return a data loader of source data with training and test set respectively
    features_train = list()  # 训练集的特征
    features_test = list()  # 测试集的特征
    labels_train = list()
    labels_test = list()

    # file_20070820A = ReadExcel(file_name='data/20080507.xls', sheet_name="A")
    # file_20070820B = ReadExcel(file_name='data/20080507.xls', sheet_name="B")
    # file_20070821A = ReadExcel(file_name="data/20080510.xls", sheet_name="A")
    # file_20070821B = ReadExcel(file_name="data/20080510.xls", sheet_name="B")
    # file_20070823A = ReadExcel(file_name='data/20080527.xls', sheet_name='A')
    # file_20070823B = ReadExcel(file_name='data/20080527.xls', sheet_name='B')

    file_19980809 = ReadExcel(file_name='data/19980809.xls',sheet_name="Sheet1")
    file_19980819 = ReadExcel(file_name="data/19980819.xls",sheet_name="Sheet1")
    file_19980822 = ReadExcel(file_name='data/19980822.xls',sheet_name="Sheet1")

    data_19980809_train = file_19980809.read_data_line(start=425, end=1217)
    data_19980809_test = file_19980809.read_data_line(start=1218, end=1415)
    data_19980819_train = file_19980819.read_data_line(start=437, end=1229)
    data_19980819_test = file_19980819.read_data_line(start=1233, end=1430)
    data_19980822_train = file_19980822.read_data_line(start=429, end=1221)
    data_19980822_test = file_19980822.read_data_line(start=1231, end=1428)

    # # 做测试对比还有算P_E_xxx这些指标

    extract_features_and_labels_19980809_train = get_features_and_labels(data_19980809_train)
    features_train.append(extract_features_and_labels_19980809_train[0])
    labels_train.append(extract_features_and_labels_19980809_train[1])
    extract_features_and_labels_19980809_test = get_features_and_labels(data_19980809_test)
    features_test.append(extract_features_and_labels_19980809_test[0])
    labels_test.append(extract_features_and_labels_19980809_test[1])

    extract_features_and_labels_19980819_train = get_features_and_labels(data_19980819_train)
    features_train.append(extract_features_and_labels_19980819_train[0])
    labels_train.append(extract_features_and_labels_19980819_train[1])
    extract_features_and_labels_19980819_test = get_features_and_labels(data_19980819_test)
    features_test.append(extract_features_and_labels_19980819_test[0])
    labels_test.append(extract_features_and_labels_19980819_test[1])

    extract_features_and_labels_19980822_train = get_features_and_labels(data_19980822_train)
    features_train.append(extract_features_and_labels_19980822_train[0])
    labels_train.append(extract_features_and_labels_19980822_train[1])
    extract_features_and_labels_19980822_test = get_features_and_labels(data_19980822_test)
    features_test.append(extract_features_and_labels_19980822_test[0])
    labels_test.append(extract_features_and_labels_19980822_test[1])


    features_train = np.array(features_train).reshape(-1, 57)
    features_test = np.array(features_test).reshape(-1, 57)

    labels_train = np.array(labels_train).reshape(-1)
    labels_test = np.array(labels_test).reshape(-1)

    # 查看维度构成
    '''
    print("feature_train:",np.array(features_train).shape)
    print("feature_test:",np.array(features_test).shape)
    print("labels_train:",np.array(labels_train).shape)
    print("labels_test:",np.array(labels_test).shape)
    '''

    # 将原始数据记录至features_raw_src和labels_raw_src
    params.features_raw_src = features_test
    params.features_raw_src = torch.tensor(params.features_raw_src).to(torch.float32)
    params.labels_raw_src = labels_test
    params.labels_raw_src = torch.tensor(params.labels_raw_src)
    params.labels_raw_src = params.labels_raw_src.long()

    # 降维，选取影响因子排在前10的测量数据，注意不要分开去对训练集和测试集做降维，这样得到的维度可能有差异！
    features = np.vstack((features_train, features_test))
    labels = np.hstack((labels_train, labels_test))
    total_rows = features.shape[0]
    features = get_five_features(features, labels, nrows=total_rows)

    # 打乱下标, 注意features打乱后labels要对应上来
    indices = np.arange(len(features))
    np.random.shuffle(indices)
    features = features[indices]
    labels = labels[indices]

    # 提取出训练集和测试集
    train_rows = features_train.shape[0]
    features_train = features[:train_rows]
    labels_train = labels[:train_rows]
    features_test = features[train_rows:]
    labels_test = labels[train_rows:]

    # 转化为张量, 同时数据类型改为torch.float32
    features_train = torch.tensor(features_train).to(torch.float32)
    # print('features_train to tensor')
    # print(features_train[0][:10])
    features_test = torch.tensor(features_test).to(torch.float32)
    # labels_train=np.array(labels_train)
    # print(labels_train[0:2])
    # labels_test=np.array(labels_test)
    labels_train = torch.tensor(labels_train)
    labels_test = torch.tensor(labels_test)
    # labels转为long类型
    labels_train = labels_train.long()
    labels_test = labels_test.long()

    train_dataset = Data.TensorDataset(features_train, labels_train)
    test_dataset = Data.TensorDataset(features_test, labels_test)

    train_dataloader = Data.DataLoader(dataset=train_dataset,
                                       batch_size=params.batch_size,
                                       shuffle=False)
    test_dataloader = Data.DataLoader(dataset=test_dataset,
                                      batch_size=params.batch_size,
                                      shuffle=False)
    return train_dataloader, test_dataloader


def get_target_dataloader(src_encoder, classifier):
    # Return a data loader of target data with training and test set respectively
    features_train = list()  # 训练集的特征
    features_test = list()  # 测试集的特征
    labels_train = list()
    labels_test = list()
    # 设立loss和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(params=list(src_encoder.parameters()) + list(classifier.parameters()),
                           lr=params.lr_src_enc,
                           betas=(params.beta1, params.beta2)
                           )

    file_19990509 = ReadExcel(file_name='data/19990509.xls',sheet_name="Sheet1")
    file_19990519 = ReadExcel(file_name="data/19990519.xls",sheet_name="Sheet1")
    file_19990523 = ReadExcel(file_name='data/19990523.xls',sheet_name="Sheet1")

    #
    data_19990509_train = file_19990509.read_data_line(start=2, end= 806)
    data_19990509_test = file_19990509.read_data_line(start=807, end=1007)
    data_19990519_train = file_19990519.read_data_line(start=431, end=1235)
    data_19990519_test = file_19990519.read_data_line(start=1240, end=1440)
    data_19990523_train = file_19990523.read_data_line(start=4745, end=5549)
    data_19990523_test = file_19990523.read_data_line(start=5563, end=5763)


    extract_features_and_labels_19990509_train = get_features_and_labels(data_19990509_train)
    features_train.append(extract_features_and_labels_19990509_train[0])
    labels_train.append(extract_features_and_labels_19990509_train[1])
    extract_features_and_labels_19990509_test = get_features_and_labels(data_19990509_test)
    features_test.append(extract_features_and_labels_19990509_test[0])
    labels_test.append(extract_features_and_labels_19990509_test[1])

    extract_features_and_labels_19990519_train = get_features_and_labels(data_19990519_train)
    features_train.append(extract_features_and_labels_19990519_train[0])
    labels_train.append(extract_features_and_labels_19990519_train[1])
    extract_features_and_labels_19990519_test = get_features_and_labels(data_19990519_test)
    features_test.append(extract_features_and_labels_19990519_test[0])
    labels_test.append(extract_features_and_labels_19990519_test[1])

    extract_features_and_labels_19990523_train = get_features_and_labels(data_19990523_train)
    features_train.append(extract_features_and_labels_19990523_train[0])
    labels_train.append(extract_features_and_labels_19990523_train[1])
    extract_features_and_labels_19990523_test = get_features_and_labels(data_19990523_test)
    features_test.append(extract_features_and_labels_19990523_test[0])
    labels_test.append(extract_features_and_labels_19990523_test[1])

    features_train = np.array(features_train).reshape(-1, 57)
    features_test = np.array(features_test).reshape(-1, 57)
    labels_train = np.array(labels_train).reshape(-1)
    labels_test = np.array(labels_test).reshape(-1)

    params.features_train_tgt = features_train
    params.labels_train_tgt = labels_train
    params.features_test_tgt = features_test
    params.labels_test_tgt = labels_test

    # 查看维度构成
    '''
    print("feature_train:",np.array(features_train).shape)
    print("feature_test:",np.array(features_test).shape)
    print("labels_train:",np.array(labels_train).shape)
    print("labels_test:",np.array(labels_test).shape)
    '''

    # 将原始数据记录至features_raw_tgt和labels_raw_tgt
    params.features_raw_tgt = features_test
    params.labels_raw_tgt = labels_test
    params.features_raw_tgt = torch.tensor(params.features_raw_tgt).to(torch.float32)
    params.labels_raw_tgt = torch.tensor(params.labels_raw_tgt)
    params.labels_raw_tgt = params.labels_raw_tgt.long()

    # 降维，选取影响因子排在前10的测量数据，注意不要分开去对训练集和测试集做降维，这样得到的维度可能有差异！
    features = np.vstack((features_train, features_test))
    labels = np.hstack((labels_train, labels_test))
    total_rows = features.shape[0]
    # 这里为什么可以提前用？我们知道目标域有几个类就行，不需要知道具体标签
    features = get_five_features(features, labels, nrows=total_rows)

    # 打乱下标, 注意features打乱后labels要对应上来
    indices = np.arange(len(features))
    np.random.shuffle(indices)
    features = features[indices]
    labels = labels[indices]
    params.features_tgt = features
    params.labels_tgt = labels

    # 提取出训练集和测试集
    train_rows = features_train.shape[0]
    features_train = features[:train_rows]
    labels_train = labels[:train_rows]
    features_test = features[train_rows:]
    labels_test = labels[train_rows:]

    params.features_train_tgt = features_train
    params.labels_train_tgt = labels_train
    params.features_test_tgt = features_test
    params.labels_test_tgt = labels_test
    # 改成tensor形式
    params.features_train_tgt = torch.tensor(params.features_train_tgt).to(torch.float32)

    # 把训练集用来半监督，每个类留几个有标签的然后进行半监督训练
    y_true = np.array(labels_train, dtype=np.int)
    ori_labels = np.array(labels_train, dtype=np.int)
    init_centers = np.zeros(shape=(params.states_num, features.shape[1]))
    init_cnt = [0 for _ in range(params.states_num)]
    used_index = []
    total = 0
    for i in range(len(y_true)):
        if init_cnt[y_true[i]] < params.nums_per_label:
            # np.array加法：同shape的对应索引内容直接相加
            init_centers[y_true[i]] = init_centers[y_true[i]] + features[i]
            init_cnt[y_true[i]] += 1
            total += 1
            used_index.append(i)

    for i in range(len(y_true)):
        if i not in used_index:
            y_true[i] = -1

    # 打包好有标签的目标域数据
    features_labeled = list()
    labels_labeled = list()
    # 打包好无标签的目标域数据
    features_unlabeled = list()
    labels_unlabeled = list()
    for i in range(len(labels_train)):
        if i not in used_index:  # 已经留标签的不采用预测结果
            # 把-1加入到伪标签中
            labels_train[i] = y_true[i]
            features_unlabeled.append(features_train[i])
            labels_unlabeled.append(labels_train[i])
        else:
            features_labeled.append(features_train[i])
            labels_labeled.append(labels_train[i])
    # 转化为张量, 同时数据类型改为torch.float32
    features_train = torch.tensor(features_train).to(torch.float32)
    features_test = torch.tensor(features_test).to(torch.float32)
    labels_train = torch.tensor(labels_train)
    labels_test = torch.tensor(labels_test)
    # labels转为long类型
    labels_train = labels_train.long()
    labels_test = labels_test.long()
    # knn要用np.array, dnn要用tensor,分开写，最后合并为features_train, labels_train (tensor)
    features_labeled = np.array(features_labeled).reshape(-1, 8)
    labels_labeled = np.array(labels_labeled).reshape(-1)
    features_unlabeled = np.array(features_unlabeled).reshape(-1, 8)
    labels_unlabeled = np.array(labels_unlabeled).reshape(-1)
    # 转换成tensor形式
    features_labeled_tensor = torch.tensor(features_labeled).to(torch.float32)
    features_unlabeled_tensor = torch.tensor(features_unlabeled).to(torch.float32)
    labels_labeled_tensor = torch.tensor(labels_labeled)
    labels_unlabeled_tensor = torch.tensor(labels_unlabeled)
    # labels转换为long的形式
    labels_labeled_tensor = labels_labeled_tensor.long()
    labels_unlabeled_tensor = labels_unlabeled_tensor.long()
    # 封装成dataset
    dataset_labeled = Data.TensorDataset(features_labeled_tensor, labels_labeled_tensor)
    dataset_unlabeled = Data.TensorDataset(features_unlabeled_tensor, labels_unlabeled_tensor)
    dataset_train = Data.TensorDataset(features_train, labels_train)
    # 封装成dataloader
    dataloader_labeled = Data.DataLoader(dataset=dataset_labeled,
                                         batch_size=params.batch_size, shuffle=False)
    dataloader_unlabeled = Data.DataLoader(dataset=dataset_unlabeled,
                                           batch_size=params.batch_size, shuffle=False)
    dataloader_train = Data.DataLoader(dataset=dataset_train,
                                       batch_size=params.batch_size, shuffle=False)
    '''
    # Assign pseudo label here
    1.相似度：LabelSpreading(KNN)
    2.soft label:微调src_encoder和classifier
    3. 对每个y<1> = y<2>的样本，赋予伪标签并加入到有标签的数据集中
    '''
    if not params.not_assign_pesudo_labels:
        # 赋予伪标签
        # 计算时间
        start = time.process_time()
        # 统计同意的总个数,初始化为原本带标签的目标域数据个数
        agree = 0
        # 统计伪标签正确的个数
        count = 0
        # 当前无标签数据个数
        cur_unlabeled = len(labels_unlabeled)
        print('total rows:', total_rows)
        for epoch in range(params.epochs_assign_pseudo_labels):
            # 需要对src_encoder和classifier做微调
            src_encoder.train()
            classifier.train()
            # 用labelspreading计算相似度上的伪标签
            label_spread_model = LabelSpreading(kernel='knn', alpha=0.89, n_neighbors=15)
            label_spread_model.fit(features_train, y_true)
            y_pred_knn = label_spread_model.predict(features_train)
            # 记录下当前标签为-1的索引
            unlabeled_idx = []
            labels_train = np.array(labels_train.cpu())
            for i in range(len(labels_train)):
                if labels_train[i] == -1:
                    unlabeled_idx.append(i)
            # 让dnn模型对有标签的目标域数据进行一个微调
            for data, labels in dataloader_labeled:
                # 加载到gpu来训练
                data = load_gpu(data)
                labels = load_gpu(labels)
                # 预测标签,计算损失
                preds = classifier(src_encoder(data))
                loss = criterion(preds, labels)
                # 优化模型
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            # 让dnn对所有无标签的数据预测一个标签
            y_pred_knn = np.array(y_pred_knn).reshape(-1)
            # 记录dnn
            y_pred_dnn = list()
            for data, _ in dataloader_train:
                # 要放到gpu
                data = load_gpu(data)
                preds = classifier(src_encoder(data))
                for pred in preds.max(1)[1]:
                    y_pred_dnn.append(pred.item())
            # 重塑维度
            y_pred_dnn = np.array(y_pred_dnn).reshape(-1)
            for i in range(len(labels_train)):
                if y_true[i] == -1 and y_pred_dnn[i] == y_pred_knn[i]:
                    y_true[i] = y_pred_dnn[i]
                    agree += 1
                    if y_true[i] == ori_labels[i]:
                        count += 1
            # 拼成新的features_train和labels_train
            features_train = np.vstack((features_labeled, features_unlabeled))
            labels_train = np.hstack((labels_labeled, labels_unlabeled))
            features_train = features_train.reshape(-1, 8)
            labels_train = labels_train.reshape(-1)
            # 重新分为有标签和无标签的
            # 打包好有标签的目标域数据
            features_labeled = list()
            labels_labeled = list()
            # 打包好无标签的目标域数据
            features_unlabeled = list()
            labels_unlabeled = list()
            for i in range(len(labels_train)):
                if labels_train[i] != -1:
                    features_labeled.append(features_train[i])
                    labels_labeled.append(labels_train[i])
                    y_true[i] = labels_train[i]
                else:
                    features_unlabeled.append(features_train[i])
                    labels_unlabeled.append(labels_train[i])
            # knn要用np.array, dnn要用tensor,分开写，最后合并为features_train, labels_train (tensor)
            features_labeled = np.array(features_labeled).reshape(-1, 8)
            labels_labeled = np.array(labels_labeled).reshape(-1)
            features_unlabeled = np.array(features_unlabeled).reshape(-1, 8)
            labels_unlabeled = np.array(labels_unlabeled).reshape(-1)

            # 转换成tensor形式
            features_labeled_tensor = torch.tensor(features_labeled).to(torch.float32)
            features_unlabeled_tensor = torch.tensor(features_unlabeled).to(torch.float32)
            labels_labeled_tensor = torch.tensor(labels_labeled)
            labels_unlabeled_tensor = torch.tensor(labels_unlabeled)
            # labels转换为long的形式
            labels_labeled_tensor = labels_labeled_tensor.long()
            labels_unlabeled_tensor = labels_unlabeled_tensor.long()
            # 转化为张量, 同时数据类型改为torch.float32
            features_train = torch.tensor(features_train).to(torch.float32)
            features_test = torch.tensor(features_test).to(torch.float32)
            labels_train = torch.tensor(labels_train)
            labels_test = torch.tensor(labels_test)
            # labels转为long类型
            labels_train = labels_train.long()
            labels_test = labels_test.long()
            # 封装成dataset
            dataset_labeled = Data.TensorDataset(features_labeled_tensor, labels_labeled_tensor)
            dataset_unlabeled = Data.TensorDataset(features_unlabeled_tensor, labels_unlabeled_tensor)
            dataset_train = Data.TensorDataset(features_train, labels_train)
            # 封装成dataloader
            dataloader_labeled = Data.DataLoader(dataset=dataset_labeled,
                                                 batch_size=params.batch_size, shuffle=False)
            dataloader_unlabeled = Data.DataLoader(dataset=dataset_unlabeled,
                                                   batch_size=params.batch_size, shuffle=False)
            dataloader_train = Data.DataLoader(dataset=dataset_train,
                                               batch_size=params.batch_size, shuffle=False)
            # 结束时间
            end = time.process_time()
            # 输出当前epoch下有多少个相同意见的
            print('Epoch [{:3}/{:3}] has {} samples ({:.2f}% of total) agreed by both. Pseudo label accuracy： '
                  '{:.2f}%. Time:{:.2f}min'.
                  format(epoch + 1, params.epochs_assign_pseudo_labels, agree,
                         agree / train_rows * 100, count / len(y_true) * 100, (end - start) / 60))

        # features_train里面还会有一些数据伪标签没有达到“共识”，舍弃掉这些数据
        # 即features_train最后对应到features_labeled
        features_train = features_labeled
        labels_train = labels_labeled

    # 转化为张量, 同时数据类型改为torch.float32
    features_train = torch.tensor(features_train).to(torch.float32)
    features_test = torch.tensor(features_test).to(torch.float32)
    labels_train = torch.tensor(labels_train)
    labels_test = torch.tensor(labels_test)
    # labels转为long类型
    labels_train = labels_train.long()
    labels_test = labels_test.long()
    # 更新Dataloader
    train_dataset = Data.TensorDataset(features_train, labels_train)
    test_dataset = Data.TensorDataset(features_test, labels_test)

    train_dataloader = Data.DataLoader(dataset=train_dataset,
                                       batch_size=params.batch_size,
                                       shuffle=False)  # 源数据集已在上方进行打乱操作
    test_dataloader = Data.DataLoader(dataset=test_dataset,
                                      batch_size=params.batch_size,
                                      shuffle=False)
    return train_dataloader, test_dataloader


if __name__ == '__main__':
    print("hello,world")
    get_source_dataloader()
