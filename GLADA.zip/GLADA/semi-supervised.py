# 半监督聚类，采用kmeans算法
import params
from sklearn.cluster import KMeans,DBSCAN
from datasets import get_source_dataloader,get_target_dataloader
from core import train_src, test_src, tada, test
from models import Encoder, Classifier, Discriminator, CenterLoss
from utils import init_model, load_model,visualize_input, visualize,draw_confusion_matrix
import torch
import numpy as np
import numpy.random as random
from PIL import Image
import matplotlib.pyplot as plt
import os
import torch.utils.data as Data
from sklearn import datasets
from sklearn.semi_supervised import LabelPropagation,LabelSpreading


if __name__== '__main__':
    seed = 123  # 固定随机数种子，保证每次加载模型结果一样
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    np.seterr(divide='ignore', invalid='ignore')
    tgt_train_test_dataloader = get_target_dataloader()
    tgt_train = tgt_train_test_dataloader[0]
    tgt_test = tgt_train_test_dataloader[1]
    features = params.features_tgt
    y_true = params.labels_tgt
    # 初始化聚类中心,每个标签设置10个参考点，以其中心为该类初始聚类中心
    y_true = np.array(y_true,dtype=np.int)
    labels = y_true
    init_centers = np.zeros(shape=(params.states_num,features.shape[1]))
    init_cnt = [0 for i in range(params.states_num)]
    used_index = []
    total = 0
    for i in range(len(y_true)):
        if init_cnt[y_true[i]] < params.nums_per_label:
            #np.array加法：同shape的对应索引内容直接相加
            init_centers[y_true[i]] = init_centers[y_true[i]]+features[i]
            init_cnt[y_true[i]] += 1
            total += 1
            used_index.append(i)

    for i in range(1000):
        if i not in used_index:
            y_true[i] = -1
    #print(used_index),15 temparay optimal
    label_prop_model = LabelSpreading(kernel='knn',alpha=0.53,n_neighbors=15)
    print(features.shape)
    label_prop_model.fit(features[:1000],y_true[:1000])
    y_pred = label_prop_model.predict(features[:1000])
    for i in range(1000):
        if i not in used_index:
            labels[i]=y_pred[i]
    print("测试正确率：%.4f"%((y_pred==labels[:1000]).sum()/1000))

    '''for i in range(init_centers.shape[0]):
        init_centers[i] = init_centers[i] / params.nums_per_label
    print(init_centers.shape)
    y_pred = KMeans(n_clusters=7,random_state=123,init=init_centers,n_init=1).fit(features)
    y_pred = y_pred.labels_
    print((y_true==y_pred).sum()/len(y_true))'''


