# A net for Task - Aware Domain Adaptation
import torch.nn as nn


class Encoder(nn.Module):
    # 处理源数据的多层感知机，其功能主要是映射数据
    # A multilayer perception machine to embed data
    def __init__(self):
        # 初始化编码器
        # Initialize the encoder
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(in_features=8, out_features=100),
            nn.ReLU(),
            nn.Linear(in_features=100, out_features=300),
            nn.ReLU(),
        )
        self.fc = nn.Linear(in_features=300, out_features=128)

    def forward(self, x):
        # 前向计算
        # forward the encoder (Calculate in direction)
        x = self.encoder(x)
        x = self.fc(x)
        # x.apply(self.init_weights(x))
        return x


class Classifier(nn.Module):
    # 做分类的多层感知机，分类为故障类型或正常
    # A multilayer perception machine to classify the embedded data
    # into a certain fault type or normal state
    def __init__(self):
        # 初始化
        # Initialize
        super(Classifier, self).__init__()
        self.classifier = nn.Sequential(
            nn.ReLU(),
            nn.Dropout(),
            nn.Linear(in_features=128, out_features=7),
        )

    def forward(self, x):
        x = self.classifier(x)
        return x


class CNN(nn.Module):
    def __init__(self, configs):
        super(CNN, self).__init__()

        self.conv_block1 = nn.Sequential(
            # 卷积核只会沿着时间步顺序进行卷积，故称为一维卷积神经网络，
            # 而二维卷积神经网络的卷积核会沿着图像的横轴和纵轴进行卷积，故称为二维卷积。
            nn.Conv1d(configs.input_channels, configs.mid_channels, kernel_size=configs.kernel_size,
                      stride=configs.stride, bias=False, padding=(configs.kernel_size // 2)),
            nn.BatchNorm1d(configs.mid_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
            nn.Dropout(configs.dropout)
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv1d(configs.mid_channels, configs.mid_channels * 2, kernel_size=8, stride=1, bias=False, padding=4),
            nn.BatchNorm1d(configs.mid_channels * 2),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1)
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv1d(configs.mid_channels * 2, configs.final_out_channels, kernel_size=8, stride=1, bias=False,
                      padding=4),
            nn.BatchNorm1d(configs.final_out_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
        )

        self.adaptive_pool = nn.AdaptiveAvgPool1d(configs.features_len)

    def forward(self, x_in):
        x = self.conv_block1(x_in)
        x = self.conv_block2(x)
        x = self.conv_block3(x)
        x = self.adaptive_pool(x)

        x_flat = x.reshape(x.shape[0], -1)
        return x_flat


class classifier(nn.Module):
    def __init__(self, configs):
        super(classifier, self).__init__()
        self.logits = nn.Linear(configs.features_len * configs.final_out_channels, configs.num_classes)

    def forward(self, x):
        predictions = self.logits(x)
        return predictions


class LSTM(nn.Module):

    def __init__(self):
        super(LSTM, self).__init__()
        self.lstm = nn.LSTM(input_size=9, hidden_size=128, num_layers=2, batch_first=True)
        self.main = nn.Sequential(
            #     nn.Linear(opt.latent_dim, 32),
            #     nn.ReLU(),
            nn.Linear(128, 100),
            nn.BatchNorm1d(32, eps=0.001, momentum=0.01),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(100, 95),
            nn.Tanh()
        )

    def forward(self, x):
        out, (h, c) = self.lstm(x)
        out = self.main(out)
        return out
