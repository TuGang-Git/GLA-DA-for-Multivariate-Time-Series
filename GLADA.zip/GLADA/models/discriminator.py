import torch.nn as nn


class Discriminator(nn.Module):
    """ Discriminator for tnet """

    def __init__(self):
        """ Initialize Discriminator  """

        super(Discriminator, self).__init__()

        self.layer = nn.Sequential(
            nn.Linear(in_features=128, out_features=128),
            nn.ReLU(),
            nn.Linear(in_features=128, out_features=128),
            nn.ReLU(),
            nn.Linear(in_features=128, out_features=1)
        )

    # 神经网络拿训练好一轮的模型计算要用到forward，优化时采用backward
    def forward(self, x):
        """ Forward the discriminator """
        # 取layer的计算结果分配给x
        x = self.layer(x)
        return x