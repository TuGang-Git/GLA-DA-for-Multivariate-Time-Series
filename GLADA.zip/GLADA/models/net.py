import torch.nn as nn

class Net(nn.Module):
    #初始化网络
    def __init__(self):
        super(Net,self).__init__()
        self.encoder=(
            nn.Linear(in_features=10, out_features=128),
            nn.ReLU(),
            nn.Linear(in_features=128, out_features=128),
            nn.ReLU(),
            nn.Linear(in_features=128, out_features=256),
            nn.ReLU()
        )
        self.classifier=(
            nn.ReLU(),
            nn.Dropout(),
            nn.Linear(in_features=256, out_features=7),
        )

    def forward(self,x):
        x = self.encoder(x)
        x = self.classifier(x)
        return  x