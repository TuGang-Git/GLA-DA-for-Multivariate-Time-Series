# GPU参数
gpu_num = 0

# 记录目标域原始特征和标签，用于（半）无监督学习
features_tgt = []
labels_tgt=[]
features_test_tgt=[]
labels_test_tgt=[]
features_train_tgt=[]
labels_train_tgt=[]

# 故障类型+正常的数目
states_num = 3


# 每个类有标签的数量
nums_per_label = 1
# 训练模型时用到的参数
# Parameters for training models
model_root = 'backup'# 保留训练过程的(半)成品模型
epochs_pre = 40
test_step_pre = 100000
save_step_pre = 100000

epochs_adapt = 50
save_step_adapt = 100

#赋予伪标签的迭代书
epochs_assign_pseudo_labels = 200

# 优化模型参数
# Parameters for optimizing models
lr_src_enc = 0.0001
lr_tgt_enc = 0.00005
lr_dis = 0.001
lr_cls = 0.001
lr_ct = 0.001 # ct -> centerloss
beta1 = 0.5
beta2 = 0.9
cla_threshold = 0.7

# 数据集和加载数据的参数
# Parameters for dataset and data loader
data_root = 'data'
batch_size = 100


# 保存可视化结果
img_root = 'img'
img_final = '08Spring_08Winter'
img_input = 'spring_winter_raw'
img_src_only = 'spring_winter_src_only'
img_tada = 'spring_winter_csda'
# cm->confusion matrix 横轴为预测值纵轴为真实值
img_cm_tada = 'CSDA_Confusion_Matrix_for_08Spring_08Winter'
img_cm_src_only = 'Source_only_Confusion_Matrix_for_08Spring_08Winter'
# 记录原始数据,在readexcel.py中添加元素，添加的是测试集数据
features_raw_src = []
labels_raw_src = []
features_raw_tgt = []
labels_raw_tgt = []

not_assign_pesudo_labels = False