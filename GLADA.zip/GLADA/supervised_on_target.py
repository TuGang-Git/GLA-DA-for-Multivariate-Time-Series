import warnings

import torchmetrics
from sklearn.semi_supervised import LabelSpreading
import copy
warnings.filterwarnings("ignore")
from sklearn import metrics
from process_excel import ReadExcel
import params
from datasets import  data_generator, Load_Dataset
from datasets.hparams import HAR_params,HHAR_params,EEG_params,WISDM_params
from datasets.data_model_configs import HAR_configs,HHAR_configs,EEG_configs,WISDM_configs
from core import train_src, test_src, tada, test
from utils import get_device,load_gpu
from models import Encoder, Classifier, Discriminator, CenterLoss, classifier, CNN
from utils import init_model, load_model, visualize_input, visualize, draw_confusion_matrix
import torch
import numpy as np
import numpy.random as random
from PIL import Image
import matplotlib.pyplot as plt
import os
import torch.utils.data as Data
from scipy.spatial.distance import euclidean
from fastdtw import fastdtw
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
if __name__ == '__main__':
    # 绑定随机数种子
    seed = 73
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    # torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    datasetName = "HAR"
    if datasetName == "HAR":
        # 获取相关参数
        hparams = HAR_params().train_params
        configs = HAR_configs()
        data_path = "D:\\Datasets\\HAR"
    if datasetName =="HHAR":
        hparams = HHAR_params().train_params
        configs = HHAR_configs()
        data_path = "D:\\Datasets\\HHAR"
    if datasetName =="EEG":
        hparams = EEG_params().train_params
        configs = EEG_configs()
        data_path = "D:\\Datasets\\EEG"
    if datasetName == "WISDM":
        hparams = WISDM_params().train_params
        configs = WISDM_configs()
        data_path = "D:\\Datasets\\WISDM"

    # 获取数据
    source_train_loader, source_test_loader = data_generator(data_path, "12", configs, hparams)
    target_train_loader, target_test_loader = data_generator(data_path, "16", configs, hparams)
    # 初始化模型
    model = init_model(CNN(configs))
    cls = init_model(classifier(configs))
    print('\n Supervised on target\n')
    model,cls = train_src(model,cls,target_train_loader,configs,hparams)
    test(model,cls,target_test_loader,configs)