import numpy as np
import xlrd
from xlrd import xldate_as_tuple


class ReadExcel:
    def __init__(self, file_name, sheet_name):
        # 打开文件:wb->workbook
        self.wb = xlrd.open_workbook(file_name)
        # 选择表单:sh->sheet
        self.sh = self.wb.sheet_by_name(sheet_name)
        self.file_name = file_name
        self.sheet_name = sheet_name

    def read_data_line(self, start=1, end=-1):  # start定义从第几行（从1开始）开始读
        total_rows = self.sh.nrows
        total_data = []  # 存储需要读的数据，后续再判断哪些不要
        # start处是栏名
        titles = []
        for title in self.sh.row_values(start - 1):
            titles.append(title)  # 把栏名添加进去
        total_data.append(titles)
        # start+1处是值
        if (end > 0 and end > total_rows) or end < 0:
            # 错误输入end或没输入end
            for current_row in range(start, total_rows):
                data = []
                for current_cell in self.sh.row(current_row):
                    # 加入当前单元格内容
                    # 先判断是否为日期
                    if current_cell.ctype == 3:
                        data.append(xldate_as_tuple(current_cell.value, datemode=0)[:3])
                    else:
                        data.append(current_cell.value)
                total_data.append(data)
        else:
            # 正确指定理想结束行数
            for current_row in range(start, end):
                data = []
                for current_cell in self.sh.row(current_row):
                    # 加入当前单元格内容
                    if current_cell.ctype == 3:
                        data.append(xldate_as_tuple(current_cell.value, datemode=0)[:3])
                    else:
                        data.append(current_cell.value)
                total_data.append(data)
        return total_data


if __name__ == '__main__':
    # wb = xlrd.open_workbook("2007summer\ASHRAE1312_fault_description.xls")
    # print("表单名字：",wb.sheet_names())
    # file = ReadExcel("data/20080507.xls", sheet_name="A")
    # data = file.read_data_line()
    # data[0].append("P_E_hcoil")
    # data[0].append("P_E_ccoil")
    # for elem in data[0]:
    #     print(elem)
    print("hello")
