import time

import torch
import torch.nn as nn
import torch.optim as optim

import params
from utils import load_gpu, save_model
from torchmetrics import Accuracy,F1Score

def train_src(src_encoder, classifier, src_loader,configs,hparams):
    # 预训练源编码器和分类器
    # Pre-train source encoder and source classifier
    # 设立loss和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(params=list(src_encoder.parameters()) + list(classifier.parameters()),
                           lr=params.lr_src_enc,
                           betas=(params.beta1, params.beta2)
                          )
   # optimizer = optim.SGD(params=list(src_encoder.parameters()) + list(classifier.parameters()),
                          #lr=params.lr_src_enc)
    # 训练模型
    start = time.process_time()  # 计算时间
    for epoch in range(1, params.epochs_pre):
        src_encoder.train()
        classifier.train()

        num_data = 0
        total_loss = 0.0

        preds_list,labels_list=[],[]

        for data, labels in src_loader:
           # data = torch.tensor(data).to(torch.float32)
            data = load_gpu(data).to(torch.float32)
            labels = load_gpu(labels)
            # print("data:",data.dtype)
            # print("labels:",labels.dtype)
            # 预测标签、计算损失
            output = src_encoder(data)
            preds = classifier(output)
            loss = criterion(preds, labels)

            # 优化模型,方法：反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 更新loss
            total_loss += loss.item()
            #把preds和labels全部记录下来
            preds_list.append(preds)
            labels_list.append(labels)
        full_preds = torch.cat((preds_list))
        full_labels = torch.cat((labels_list))

        #计算准确率和mf1
        cal_acc = Accuracy(task="multiclass",num_classes=configs.num_classes)
        cal_f1 = F1Score(task="multiclass",num_classes=configs.num_classes,average="macro")
        acc = cal_acc(full_preds.argmax(dim=1).cpu(),full_labels.cpu()).item()
        mf1 = cal_f1(full_preds.argmax(dim=1).cpu(),full_labels.cpu()).item()



        total_loss = total_loss / len(src_loader)

        # Print log information
        end = time.process_time()
        print('Epoch [{:3}/{:3}] : loss={:8.4f}, acc={:.4f}, mf1={:.4f},time={:.2f}min'.format(
            epoch, params.epochs_pre, total_loss,acc, mf1,(end - start) / 60
        ))

        # Test model performence
        if epoch % params.test_step_pre == 0:
            test_src(src_encoder, classifier, src_loader)

        # Save model parameters
        if epoch % params.save_step_pre == 0:
            print('\n#=========================================#\n')
            print('\tSave source model parameters\n')
            save_model(src_encoder, 'src-encoder-{}.pt'.format(epoch))
            save_model(classifier, 'classifier-{}.pt'.format(epoch))
            print('\n#=========================================#\n')

    # Save final model parameters
    print('\n#=========================================#\n')
    print('\tSave source model parameters\n')
    save_model(src_encoder, 'src-encoder-final.pt')
    save_model(classifier, 'classifier-final.pt')
    print('\n#=========================================#\n')

    return src_encoder, classifier


def test_src(src_encoder, classifier, src_loader,configs,hparams):
    """ Test source encoder and classifier """

    src_encoder.eval()
    classifier.eval()

    # Setup criterion
    criterion = nn.CrossEntropyLoss()

    num_data = 0
    total_acc = 0.0
    total_loss = 0.0
    count = 1
    # Test model
    with torch.no_grad():
        preds_list, labels_list = [], []
        for data, labels in src_loader:
            # nn.Linear只认float32，要改一下类型(readexcel.py里改了)
            data = load_gpu(data).to(torch.float32)
            labels = load_gpu(labels)

            # Predict labels and compute loss
            if count == 1:
               # print(type(src_encoder(data)))
               # print(type(classifier(src_encoder(data))))
                count = 0
            preds = classifier(src_encoder(data))
            loss = criterion(preds, labels)

            # Update total loss and total accuracy
            num_data += len(labels)
            # 把preds和labels全部记录下来
            preds_list.append(preds)
            labels_list.append(labels)
            total_loss += loss.item()
        full_preds = torch.cat((preds_list))
        full_labels = torch.cat((labels_list))

        # 计算准确率和mf1
        # 计算准确率和mf1
        cal_acc = Accuracy(task="multiclass", num_classes=configs.num_classes)
        cal_f1 = F1Score(task="multiclass", num_classes=configs.num_classes, average="macro")
        acc = cal_acc(full_preds.argmax(dim=1).cpu(), full_labels.cpu()).item()
        mf1 = cal_f1(full_preds.argmax(dim=1).cpu(), full_labels.cpu()).item()
        total_loss = total_loss / len(src_loader)


    print('\n#=========================================#\n')
    print('\t    Test source model\n')
    print('\t   Loss      = {:8.4f}'.format(total_loss))
    print('\t   Accuracy  = {:8.4f}'.format(acc))
    print('\t   M-F1score = {:8.4f}'.format(mf1))
    print('\n#=========================================#\n')
