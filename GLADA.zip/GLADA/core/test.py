import torch
import torchmetrics

from utils import load_gpu
import logging


def test(encoder, classifier, loader,configs):
    # Set model mode
    encoder.eval()
    classifier.eval()
    # Test model
    with torch.no_grad():
        preds_list, labels_list = [], []
        for images, labels in loader:
            # load images and labels to GPU
            images = load_gpu(images).to(torch.float32)
            labels = load_gpu(labels)
            # Predict labels and compute loss
            preds = classifier(encoder(images))
            # Update total loss and total accuracy
            preds_list.append(preds)
            labels_list.append(labels)
        full_preds = torch.cat((preds_list))
        full_labels = torch.cat((labels_list))
        # 计算准确率和mf1
        # 计算准确率和mf1
        cal_acc = torchmetrics.Accuracy(task="multiclass", num_classes=configs.num_classes)
        cal_f1 = torchmetrics.F1Score(task="multiclass", num_classes=configs.num_classes, average="macro")
        acc = cal_acc(full_preds.argmax(dim=1).cpu(), full_labels.cpu()).item()
        mf1 = cal_f1(full_preds.argmax(dim=1).cpu(), full_labels.cpu()).item()

    print('   - Accuracy = {:.4f}'.format(acc))
    print('   - M-F1score = {:.4f}'.format(mf1))
    logging.info('   - Accuracy = {:.4f}'.format(acc))
    logging.info('   - M-F1score = {:.4f}'.format(mf1))
