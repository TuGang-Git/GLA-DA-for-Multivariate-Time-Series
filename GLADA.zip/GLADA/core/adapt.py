import torch
import torch.nn as nn
import torch.optim as optim
from models import CenterLoss
import params
from utils import set_requires_grad, load_gpu, save_model
import time

# 训练目标映射器，微调源映射器
def tada(src_encoder, tgt_encoder, discriminator, src_loader, tgt_loader,classifier,configs):

    # 判别器的优化损失函数：二元分类
    criterion = nn.BCEWithLogitsLoss() # BCEWith... = sigmoid + BCELoss
    criterion_gen = nn.CrossEntropyLoss()
    #UCIHAR num_classes=6,feat_dim=128
    #HHAR num_classes=6,feat_dim=128
    #EEG num_classes=5,feat_dim=128
    #WISDM num_classes=6,feat_dim=128

    criterion_ct = CenterLoss(num_classes=configs.num_classes,feat_dim=128) # feat_dim是编码器映射后的维度
    criterion_cls = nn.CrossEntropyLoss()

    # 优化器，分别用于改变源和目标encoder的参数、优化判别器和源分类器
    optim_enc = optim.Adam(params=list(src_encoder.parameters())+list(tgt_encoder.parameters()),
                           lr=params.lr_tgt_enc,
                           betas=(params.beta1,params.beta2))
    optim_dis = optim.Adam(params=discriminator.parameters(),
                           lr=params.lr_dis,
                           betas=(params.beta1,params.beta2)
                           )
    optim_ct = optim.Adam(params=list(src_encoder.parameters())+list(tgt_encoder.parameters()),
                           lr=params.lr_ct,
                           betas=(params.beta1,params.beta2)
                           ) # ct -> centerloss
    optim_cls = optim.Adam(params=classifier.parameters(),
                           lr=params.lr_cls,
                           betas=(params.beta1,params.beta2))
    # 计算程序运行时间
    start = time.process_time()
    # 开始进行适应：先训练判别器，再训练两个映射器，再令各个类之间有一定距离
    for epoch in range(1, params.epochs_adapt + 1):
        src_encoder.train()
        classifier.train()
        num_data = 0
        total_acc = 0.0
        total_loss_enc = 0.0
        total_loss_dis = 0.0
        total_loss_ct = 0.0
        total_loss_cls = 0.0

        for (data_src, label_src), (data_tgt, label_tgt) in zip(src_loader, tgt_loader):
            data_src = data_src.to(torch.float32)
            data_tgt = data_tgt.to(torch.float32)
            #===========================#
            #    1：训练判别器            #
            #===========================#
            set_requires_grad(classifier, requires_grad=False)
            set_requires_grad(src_encoder, requires_grad=False)
            set_requires_grad(tgt_encoder, requires_grad=False)
            set_requires_grad(discriminator, requires_grad=True)

            # 把数据加载到GPU上
            data_src = load_gpu(data_src)
            data_tgt = load_gpu(data_tgt)
            label_src = load_gpu(label_src)
            label_tgt = load_gpu(label_tgt)

            # 创建域标签, 源域的为0，目标域的为1
            labels_dis = torch.cat([torch.ones(data_src.shape[0]),
                                    torch.zeros(data_tgt.shape[0])],0)
            labels_dis = load_gpu(labels_dis)

            # 提取映射后的特征数据
            features_src = src_encoder(data_src)
            features_tgt = tgt_encoder(data_tgt)
            features_concat = torch.cat([features_src,features_tgt],0)

            # 预测领域标签，计算损失
            preds = discriminator(features_concat).squeeze() # squeeze可以维度为1的去掉
            loss = criterion(preds,labels_dis) # 判别器应该能明显看出两域差异

            # 优化判别器
            optim_dis.zero_grad()
            loss.backward()
            optim_dis.step()

            # 更新loss和正确率
            num_data += len(labels_dis)
            total_acc += ((preds > 0).long() == labels_dis.long()).sum().item()
            total_loss_dis += loss.item()

            # ===========================#
            #   2.训练源和目标映射器        #
            # ===========================#

            # 训练完能很好地辨别源域和目标域的判别器后，开始让两映射器能让两域数据能“骗过”判别器

            # 打开源和目标映射器梯度，关闭判别器梯度
            set_requires_grad(src_encoder,requires_grad=True)
            set_requires_grad(tgt_encoder,requires_grad=True)
            set_requires_grad(discriminator,requires_grad=False)

            # 把数据加载到GPU上
            data_src = load_gpu(data_src).to(torch.float32)
            data_tgt = load_gpu(data_tgt).to(torch.float32)

            # 既然需要调整源映射器，那就需要改一下label，这里设置为0.5
            labels_list = [0.5 for _ in range(data_src.shape[0]+data_tgt.shape[0])]
            labels = torch.tensor(labels_list)
            labels = load_gpu(labels)

            # 预测域标签并计算loss
            compute = torch.cat([features_src,features_tgt],0)
            preds = discriminator(compute).squeeze()
            loss = criterion(preds,labels)
            loss = loss.requires_grad_()
            # 优化源和目标映射器
            optim_enc.zero_grad()
            loss.backward()
            optim_enc.step()

            # 更新loss
            total_loss_enc += loss.item()

            # ===========================#
            #   3.增强样本间不同域的各类差异 #
            # ===========================#
            new_features_src = src_encoder(data_src)
            new_features_tgt = tgt_encoder(data_tgt)
            new_features_concat = torch.cat([new_features_src,new_features_tgt],0)
            new_labels_concat = torch.cat([label_src,label_tgt],0)
            # print(type(new_features_concat),type(new_labels_concat))
            loss = criterion_ct(new_labels_concat,new_features_concat) # 这个算法是label在前,features在后
            # loss = load_gpu(loss)
            loss = loss.requires_grad_()
            # 再优化源和目标映射器
            optim_ct.zero_grad()
            loss.backward()
            optim_ct.step()

            # 更新loss
            total_loss_ct += loss.item()

            # ===========================#
            #   4.训练一个共享分类器        #
            # ===========================#

            # 关闭映射器的梯度,打开分类器的梯度
            set_requires_grad(src_encoder, requires_grad=False)
            set_requires_grad(tgt_encoder, requires_grad=False)
            set_requires_grad(classifier, requires_grad=True)

            new_features_src_cls = src_encoder(data_src)
            new_features_tgt_cls = tgt_encoder(data_tgt)
            new_features_concat_cls = torch.cat([new_features_src_cls, new_features_tgt_cls], 0)
            new_labels_concat_cls = torch.cat([label_src, label_tgt], 0)
            preds = classifier(new_features_concat_cls)
            loss = criterion_cls(preds,new_labels_concat_cls)
            loss = loss.requires_grad_()
            # 再优化源分类器
            optim_cls.zero_grad()
            loss.backward()
            optim_cls.step()

            # 更新loss
            total_loss_cls += loss.item()

        loader_len = min(len(src_loader), len(tgt_loader))
        total_acc = total_acc / num_data
        total_loss_dis = total_loss_dis / loader_len
        total_loss_enc = total_loss_enc / loader_len
        total_loss_ct = total_loss_ct / loader_len
        total_loss_cls = total_loss_cls / loader_len
        end = time.process_time() # 本轮迭代结束时间

        # 输出日志信息
        print('Epoch [{:3}/{:3}] : d_loss={:8.4f},g_loss={:8.4f}, ct_loss={:8.4f},cls_loss={:8.4f},acc={:.4f}, time={:.2f}min'.format(
            epoch, params.epochs_adapt, total_loss_dis, total_loss_enc,total_loss_ct,total_loss_cls,total_acc, (end - start) / 60
        ))

        # Save model parameters
        if epoch % params.save_step_adapt == 0:
            print('\n#=========================================#\n')
            print('\tSave source, target and classifier model parameters\n')
            save_model(src_encoder, 'src-encoder-{}new.pt'.format(epoch))
            save_model(tgt_encoder, 'tgt-encoder-{}.pt'.format(epoch))
            save_model(classifier,'classifier-{}new.pt'.format(epoch))
            print('#=========================================#\n')

    # Save final model parameters
    print('\n#=========================================#\n')
    print('\tSave source, target and classifier model parameters\n')
    save_model(src_encoder, 'src-encoder-final-new.pt')
    save_model(tgt_encoder, 'tgt-encoder-final.pt')
    save_model(classifier,'classifier-final-new.pt')
    print('#=========================================#\n')

    return src_encoder,tgt_encoder,classifier   # 返回我们需要的三样：两域各自的映射器和分类器

def tada_without3(src_encoder, tgt_encoder, discriminator, src_loader, tgt_loader,classifier,configs):

    # 判别器的优化损失函数：二元分类
    criterion = nn.BCEWithLogitsLoss() # BCEWith... = sigmoid + BCELoss
    criterion_gen = nn.CrossEntropyLoss()
    #UCIHAR num_classes=6,feat_dim=128
    #HHAR num_classes=6,feat_dim=128
    #EEG num_classes=5,feat_dim=128
    #WISDM num_classes=6,feat_dim=128

    criterion_ct = CenterLoss(num_classes=configs.num_classes,feat_dim=128) # feat_dim是编码器映射后的维度
    criterion_cls = nn.CrossEntropyLoss()

    # 优化器，分别用于改变源和目标encoder的参数、优化判别器和源分类器
    optim_enc = optim.Adam(params=list(src_encoder.parameters())+list(tgt_encoder.parameters()),
                           lr=params.lr_tgt_enc,
                           betas=(params.beta1,params.beta2))
    optim_dis = optim.Adam(params=discriminator.parameters(),
                           lr=params.lr_dis,
                           betas=(params.beta1,params.beta2)
                           )
    optim_ct = optim.Adam(params=list(src_encoder.parameters())+list(tgt_encoder.parameters()),
                           lr=params.lr_ct,
                           betas=(params.beta1,params.beta2)
                           ) # ct -> centerloss
    optim_cls = optim.Adam(params=classifier.parameters(),
                           lr=params.lr_cls,
                           betas=(params.beta1,params.beta2))
    # 计算程序运行时间
    start = time.process_time()
    # 开始进行适应：先训练判别器，再训练两个映射器，再令各个类之间有一定距离
    for epoch in range(1, params.epochs_adapt + 1):
        src_encoder.train()
        classifier.train()
        num_data = 0
        total_acc = 0.0
        total_loss_enc = 0.0
        total_loss_dis = 0.0
        total_loss_ct = 0.0
        total_loss_cls = 0.0

        for (data_src, label_src), (data_tgt, label_tgt) in zip(src_loader, tgt_loader):
            data_src = data_src.to(torch.float32)
            data_tgt = data_tgt.to(torch.float32)
            #===========================#
            #    1：训练判别器            #
            #===========================#
            set_requires_grad(classifier, requires_grad=False)
            set_requires_grad(src_encoder, requires_grad=False)
            set_requires_grad(tgt_encoder, requires_grad=False)
            set_requires_grad(discriminator, requires_grad=True)

            # 把数据加载到GPU上
            data_src = load_gpu(data_src)
            data_tgt = load_gpu(data_tgt)
            label_src = load_gpu(label_src)
            label_tgt = load_gpu(label_tgt)

            # 创建域标签, 源域的为0，目标域的为1
            labels_dis = torch.cat([torch.ones(data_src.shape[0]),
                                    torch.zeros(data_tgt.shape[0])],0)
            labels_dis = load_gpu(labels_dis)

            # 提取映射后的特征数据
            features_src = src_encoder(data_src)
            features_tgt = tgt_encoder(data_tgt)
            features_concat = torch.cat([features_src,features_tgt],0)

            # 预测领域标签，计算损失
            preds = discriminator(features_concat).squeeze() # squeeze可以维度为1的去掉
            loss = criterion(preds,labels_dis) # 判别器应该能明显看出两域差异

            # 优化判别器
            optim_dis.zero_grad()
            loss.backward()
            optim_dis.step()

            # 更新loss和正确率
            num_data += len(labels_dis)
            total_acc += ((preds > 0).long() == labels_dis.long()).sum().item()
            total_loss_dis += loss.item()

            # ===========================#
            #   2.训练源和目标映射器        #
            # ===========================#

            # 训练完能很好地辨别源域和目标域的判别器后，开始让两映射器能让两域数据能“骗过”判别器

            # 打开源和目标映射器梯度，关闭判别器梯度
            set_requires_grad(src_encoder,requires_grad=True)
            set_requires_grad(tgt_encoder,requires_grad=True)
            set_requires_grad(discriminator,requires_grad=False)

            # 把数据加载到GPU上
            data_src = load_gpu(data_src).to(torch.float32)
            data_tgt = load_gpu(data_tgt).to(torch.float32)

            # 既然需要调整源映射器，那就需要改一下label，这里设置为0.5
            labels_list = [0.5 for _ in range(data_src.shape[0]+data_tgt.shape[0])]
            labels = torch.tensor(labels_list)
            labels = load_gpu(labels)

            # 预测域标签并计算loss
            compute = torch.cat([features_src,features_tgt],0)
            preds = discriminator(compute).squeeze()
            loss = criterion(preds,labels)
            loss = loss.requires_grad_()
            # 优化源和目标映射器
            optim_enc.zero_grad()
            loss.backward()
            optim_enc.step()

            # 更新loss
            total_loss_enc += loss.item()

            # ===========================#
            #   3.增强样本间不同域的各类差异 #
            # ===========================#
            # new_features_src = src_encoder(data_src)
            # new_features_tgt = tgt_encoder(data_tgt)
            # new_features_concat = torch.cat([new_features_src,new_features_tgt],0)
            # new_labels_concat = torch.cat([label_src,label_tgt],0)
            # # print(type(new_features_concat),type(new_labels_concat))
            # loss = criterion_ct(new_labels_concat,new_features_concat) # 这个算法是label在前,features在后
            # # loss = load_gpu(loss)
            # loss = loss.requires_grad_()
            # # 再优化源和目标映射器
            # optim_ct.zero_grad()
            # loss.backward()
            # optim_ct.step()
            #
            # # 更新loss
            # total_loss_ct += loss.item()

            # ===========================#
            #   4.训练一个共享分类器        #
            # ===========================#

            # 关闭映射器的梯度,打开分类器的梯度
            set_requires_grad(src_encoder, requires_grad=False)
            set_requires_grad(tgt_encoder, requires_grad=False)
            set_requires_grad(classifier, requires_grad=True)

            new_features_src_cls = src_encoder(data_src)
            new_features_tgt_cls = tgt_encoder(data_tgt)
            new_features_concat_cls = torch.cat([new_features_src_cls, new_features_tgt_cls], 0)
            new_labels_concat_cls = torch.cat([label_src, label_tgt], 0)
            preds = classifier(new_features_concat_cls)
            loss = criterion_cls(preds,new_labels_concat_cls)
            loss = loss.requires_grad_()
            # 再优化源分类器
            optim_cls.zero_grad()
            loss.backward()
            optim_cls.step()

            # 更新loss
            total_loss_cls += loss.item()

        loader_len = min(len(src_loader), len(tgt_loader))
        total_acc = total_acc / num_data
        total_loss_dis = total_loss_dis / loader_len
        total_loss_enc = total_loss_enc / loader_len
        total_loss_ct = total_loss_ct / loader_len
        total_loss_cls = total_loss_cls / loader_len
        end = time.process_time() # 本轮迭代结束时间

        # 输出日志信息
        print('Epoch [{:3}/{:3}] : d_loss={:8.4f},g_loss={:8.4f}, ct_loss={:8.4f},cls_loss={:8.4f},acc={:.4f}, time={:.2f}min'.format(
            epoch, params.epochs_adapt, total_loss_dis, total_loss_enc,total_loss_ct,total_loss_cls,total_acc, (end - start) / 60
        ))

        # Save model parameters
        if epoch % params.save_step_adapt == 0:
            print('\n#=========================================#\n')
            print('\tSave source, target and classifier model parameters\n')
            save_model(src_encoder, 'src-encoder-{}new.pt'.format(epoch))
            save_model(tgt_encoder, 'tgt-encoder-{}.pt'.format(epoch))
            save_model(classifier,'classifier-{}new.pt'.format(epoch))
            print('#=========================================#\n')

    # Save final model parameters
    print('\n#=========================================#\n')
    print('\tSave source, target and classifier model parameters\n')
    save_model(src_encoder, 'src-encoder-final-new.pt')
    save_model(tgt_encoder, 'tgt-encoder-final.pt')
    save_model(classifier,'classifier-final-new.pt')
    print('#=========================================#\n')

    return src_encoder,tgt_encoder,classifier   # 返回我们需要的三样：两域各自的映射器和分类器

